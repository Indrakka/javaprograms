package com.edu;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Vector;

public class ArrayListDemo {

	public static void main(String[] args) {
		List<Integer> lst=new LinkedList<Integer>();
		lst.add(34);
		lst.add(87);
		lst.add(76);
		lst.add(98);
		//lst.sort();;
		System.out.println(lst);
		lst.remove(3);
		
		System.out.println(lst);
		System.out.println(lst.contains(34));
		ArrayList<Integer> lst1=new ArrayList<Integer>();
		lst1.add(34);
		lst1.add(83);
		lst1.add(76);
		System.out.println(lst.containsAll(lst1));
		
		/*lst.clear();
		System.out.println("After clear "+lst);
		*/
		lst.addAll(lst1);
		System.out.println(lst);
		
		//iterate one by one element
		
	     Iterator<Integer> it=lst.iterator();
	     //hasNext()->return true if list has elements
	     //next()->ArrayList element
	     System.out.println("Arraylist elements are");
	     while(it.hasNext()) {
	    	 System.out.println(it.next());
	     }
	     
	     //for each loop enhanced loop
	     for(Integer i:lst) {
	    	 System.out.println(i);
	     }
	     
	     lst.remove(2);
	     
	     System.out.println("After removing first element");
	     System.out.println(lst);
	}

}
