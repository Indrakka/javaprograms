package com.edu.mappack;

import java.util.HashMap;
import java.util.Map;

public class CharacterCountInWord {
	private static void occurranceChar(String word) {
		//word split into chararray
		char ch[]=word.toCharArray();//ch={'G','E','O','R','G',E'}
		
		HashMap<Character,Integer>chcnt=new HashMap<Character,Integer>();
		
		for(char c:ch) {
			if(chcnt.containsKey(c)) {
				chcnt.put(c, chcnt.get(c)+1);
				System.out.println(chcnt.get(c));
			}else {
				//if char is not there in HaspMap
				chcnt.put(c, 1);
			}
		}
		
		//Display using Entry
		for(Map.Entry<Character, Integer> m:chcnt.entrySet())
		{
			System.out.println(m.getKey()+"->"+m.getValue());
		}
		
	}

	public static void main(String[] args) {
		String word="GEORGE";
		occurranceChar(word);
	}

}
