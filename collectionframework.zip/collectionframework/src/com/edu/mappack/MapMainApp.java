package com.edu.mappack;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.TreeMap;

public class MapMainApp {

	public static void main(String[] args) {
		Map<Integer,String>mapobj=new HashMap<Integer,String>();
		System.out.println("HashMap does not maintains insertion order ");
		mapobj.put(1111, "Kiran");
		mapobj.put(1112, "Manoj");
		mapobj.put(1113, "Swetha");
		mapobj.put(1114, "Ravi");
		mapobj.put(1115, "Kiran");
		
		System.out.println(mapobj);
		
		System.out.println("LinkedHashMap maintains the insertion order");
		Map<Integer,String>mapobj1=new LinkedHashMap<Integer,String>();
		System.out.println("LinkedHashMap  maintains insertion order ");
		mapobj1.put(1111, "Kiran");
		mapobj1.put(1112, "Manoj");
		mapobj1.put(1113, "Swetha");
		mapobj1.put(1114, "Ravi");
		mapobj1.put(1115, "Kiran");
		
		System.out.println(mapobj1);
		//TreeMap
		System.out.println("TreeMap elements will be in ascending order");
		Map<String,String>mapobj2=new TreeMap<String,String>();
		System.out.println("Tree Map elements will be sorted based ob key");
		mapobj2.put("9880759294", "Kiran");
		mapobj2.put("9880659294", "Manoj");
		mapobj2.put("9870759294", "Swetha");
		mapobj2.put("9880759292", "Ravi");
		mapobj2.put("9880559294", "Kiran");
		
		System.out.println(mapobj2);
		
		//Traverse Map elements
		for(Map.Entry<String,String> pmap:mapobj2.entrySet()) {
			System.out.println(pmap.getKey()+"  "+pmap.getValue());
			
		}
		
	}
}
//TreeMap store Mobileno and name and display