package com.edu.user;

import java.util.ArrayList;
import java.util.Collections;

public class SortExampleArrayList {

	public static void main(String[] args) {
		ArrayList<Integer> alist=new ArrayList<Integer>();
		alist.add(76);
		alist.add(32);
		alist.add(9);
		alist.add(12);
		
		System.out.println(alist);
		Collections.sort(alist);
		System.out.println("After sorting "+alist);

	}

}
