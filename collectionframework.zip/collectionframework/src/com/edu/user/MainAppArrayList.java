package com.edu.user;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;

class Employee{
	int employeeId;
	String employeeName;
	float employeeSalary;
	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Employee(int employeeId, String employeeName, float employeeSalary) {
		super();
		this.employeeId = employeeId;
		this.employeeName = employeeName;
		this.employeeSalary = employeeSalary;
	}
	@Override
	public String toString() {
		return "Employee [employeeId=" + employeeId + ", employeeName=" + employeeName + ", employeeSalary="
				+ employeeSalary + "]";
	}
	
}

//sort based on salary

class EmployeeSortSalary implements Comparator<Employee>{

	@Override
	public int compare(Employee e1, Employee e2) {
		if(e1.employeeSalary==e2.employeeSalary)
		     return 0;
		else if(e1.employeeSalary>e2.employeeSalary)
			return 1;
		else
			return -1;
		
	}
}

class EmployeeSortId implements Comparator<Employee>{

	@Override
	public int compare(Employee e1, Employee e2) {
		if(e1.employeeId==e2.employeeId)
		     return 0;
		else if(e1.employeeId>e2.employeeId)
			return 1;
		else
			return -1;
		
	}
}
//Sort Based on Name
class EmployeeSortName implements Comparator<Employee>{

	@Override
	public int compare(Employee e1, Employee e2) {
		
		return e1.employeeName.compareTo(e2.employeeName);
	}
	
}//close
public class MainAppArrayList {
	
	public static void main(String[] args) {
		
	
	Employee e1=new Employee(1121, "Sonali", 68647.65f);
	Employee e2=new Employee(1012, "Prathiksha", 88635.65f);
	Employee e3=new Employee(1113, "George", 18624.65f);
	
	ArrayList<Employee>elst=new ArrayList<Employee>();
	
	elst.add(e1);
	elst.add(e2);
	elst.add(e3);
	
	System.out.println(elst);
	
	//Iterator
	Iterator<Employee>eob=elst.iterator();
	System.out.println("Before sort");
	System.out.println("ID\tName\tSalary");
	System.out.println("_________________________________________");
	while(eob.hasNext()) {
	Employee employeeObject= eob.next();
	System.out.println(employeeObject.employeeId+"\t"+employeeObject.employeeName+"\t"+employeeObject.employeeSalary);
		
	}
	
	//Sort Employee Data Based on Salary
	EmployeeSortSalary esort=new EmployeeSortSalary();
	Collections.sort(elst,esort);
	System.out.println("After Sort based on salary\n\n");
	Iterator<Employee>eob1=elst.iterator();
	System.out.println("ID\tSalary\tName");
	System.out.println("_________________________________________");
	while(eob1.hasNext()) {
	Employee employeeObject= eob1.next();
	System.out.println(employeeObject.employeeId+"\t"+employeeObject.employeeSalary+"\t"+employeeObject.employeeName);
		
	}
	//Sort Employee Data Based on Id
	Collections.sort(elst,new EmployeeSortId());
	System.out.println(elst);
	System.out.println("After Sort based on Employee Id\n\n");
	Iterator<Employee>eob2=elst.iterator();
	System.out.println("ID\tSalary\tName");
	System.out.println("_________________________________________");
	while(eob2.hasNext()) {
	Employee employeeObject= eob2.next();
	System.out.println(employeeObject.employeeId+"\t"+employeeObject.employeeSalary+"\t"+employeeObject.employeeName);
		
	}
	
	//Sort based on Name
	
	Collections.sort(elst,new EmployeeSortName());
	System.out.println("After Sort based on Employee Name\n\n");
	Iterator<Employee>eob3=elst.iterator();
	System.out.println("ID\tSalary\tName");
	System.out.println("_________________________________________");
	while(eob3.hasNext()) {
	Employee employeeObject= eob3.next();
	System.out.println(employeeObject.employeeId+"\t"+employeeObject.employeeSalary+"\t"+employeeObject.employeeName);
		
	}
	
   }
}

