package com.edu.setint;

import java.util.HashSet;
import java.util.Set;
import java.util.TreeSet;

public class TreeSetExample {

	public static void main(String[] args) {
		Set<Integer>tset=new TreeSet<Integer>();
		//features 1.no duplicate  2.does not maintains insertion order
		//single null is allowed
		tset.add(98);
		tset.add(12);
		tset.add(9);
		tset.add(128);
		tset.add(9);
		
		System.out.println(tset);
	}

}
