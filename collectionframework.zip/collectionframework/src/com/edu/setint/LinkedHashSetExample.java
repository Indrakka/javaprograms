package com.edu.setint;

import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Set;

public class LinkedHashSetExample {

	public static void main(String[] args) {
		Set<Integer>lhset=new LinkedHashSet<Integer>();
		//features 1.no duplicate  2. maintains insertion order
		//single null is allowed
		lhset.add(98);
		lhset.add(12);
		lhset.add(9);
		lhset.add(128);
		lhset.add(9);
		lhset.add(null);
		lhset.add(null);
		System.out.println(lhset);

	}

}
