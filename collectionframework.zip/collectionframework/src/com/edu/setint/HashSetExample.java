package com.edu.setint;

import java.util.HashSet;
import java.util.Set;

public class HashSetExample {

	public static void main(String[] args) {
		Set<Integer>hset=new HashSet<Integer>();
		//features 1.no duplicate  2.does not maintains insertion order
		//single null is allowed
		hset.add(98);
		hset.add(12);
		hset.add(9);
		hset.add(128);
		hset.add(9);
		hset.add(null);
		hset.add(null);
		System.out.println(hset);
		
	}

}
